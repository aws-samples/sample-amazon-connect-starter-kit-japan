// src/version.js
export const VERSION = '1.0.0';
export const BUILD_TIME = '2025.05.13';
